import React from 'react';

function UserForm(props) {
  return (
    <div>
      <label htmlFor="user-name">User: </label>
      <input
        id="user-name"
        name="user-name"
        type="text"
        onChange={props.handleUserNameChange}
      />

      <p>Searching for a new user named: {props.userName}</p>
    </div>
  );
}

export default UserForm;