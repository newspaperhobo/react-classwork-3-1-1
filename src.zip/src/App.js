import React, { useState } from 'react';
import UserItem from './User/UserItem';
import UserForm from './User/UserForm';

function App() {
  const users = [
    {
      id: 1,
      name: "name1",
      location: "location1",
      followers: 46,
      following: 54
    },
    {
      id: 2,
      name: "name2",
      location: "location2",
      followers: 100,
      following: 1
    }
  ];

  const [userName, setUserName] = useState("");

  const handleUserNameChange = (event) => {
    console.log(event.target.value);
    setUserName(event.target.value);
  };

  return (
    <div className="App">
      <h1>Users</h1>

      <UserForm
        userName={userName}
        handleUserNameChange={handleUserNameChange}
      />

      <hr />

      <UserItem users={users} />
    </div>
  );
}

export default App;